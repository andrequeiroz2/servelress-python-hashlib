import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='andrequeiroz2',
    application_name='calcpython',
    app_uid='6JWdpxVQ71TctVPSpm',
    org_uid='4204b739-10d2-4eab-8ad9-e945faabc7a5',
    deployment_uid='8a9eb114-2ea1-4ebc-a7de-966027143b96',
    service_name='calc',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.4.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'calc-dev-hello', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('handler.hello')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
